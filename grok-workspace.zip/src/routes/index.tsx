import { createFileRoute } from "@tanstack/react-router";
import { BlockholdApp } from "@/components/blockhold-app";

export const Route = createFileRoute("/")({
  component: BlockholdApp,
});
