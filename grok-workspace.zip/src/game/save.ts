const KEY = "blockhold-save-v1";

export type SaveData = {
  v: 1;
  seed: number;
  edits: number[];
  player: {
    x: number;
    y: number;
    z: number;
    yaw: number;
    pitch: number;
    flying: boolean;
    slot: number;
  };
};

export function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as SaveData;
    if (!data || data.v !== 1 || !Array.isArray(data.edits) || !data.player) return null;
    return data;
  } catch {
    return null;
  }
}

export function writeSave(data: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* storage full or blocked — the world still runs */
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
