import { AIR, BEDROCK, COBBLE, DIRT, GRASS, LEAVES, LOG, SAND, SOLID, STONE, WATER } from "@/game/blocks";
import { hash01, noise2 } from "@/game/noise";

export const SX = 16;
export const SY = 48;
export const SZ = 16;
export const SEA = 16;

export type Chunk = {
  cx: number;
  cz: number;
  blocks: Uint8Array;
  base: Uint8Array;
};

export function index(lx: number, y: number, lz: number): number {
  return lx + SX * (y + SY * lz);
}

export function chunkKey(cx: number, cz: number): string {
  return `${cx},${cz}`;
}

export function terrainHeight(x: number, z: number, seed: number): number {
  let n =
    noise2(x * 0.011, z * 0.011, seed) * 11 +
    noise2(x * 0.042, z * 0.042, seed + 11) * 4.5 +
    noise2(x * 0.1, z * 0.1, seed + 29) * 1.5;
  const d = Math.hypot(x, z);
  if (d < 24) {
    const k = 1 - d / 24;
    n = n * (1 - k * 0.92) + 4.2 * k;
  }
  return Math.max(7, Math.min(SY - 12, Math.floor(SEA + n)));
}

function writeLocal(blocks: Uint8Array, cx: number, cz: number, x: number, y: number, z: number, id: number, onlyAir: boolean) {
  if (y < 0 || y >= SY) return;
  const lx = x - cx * SX;
  const lz = z - cz * SZ;
  if (lx < 0 || lz < 0 || lx >= SX || lz >= SZ) return;
  const i = index(lx, y, lz);
  if (onlyAir && blocks[i] !== AIR) return;
  blocks[i] = id;
}

function stampTree(blocks: Uint8Array, cx: number, cz: number, tx: number, tz: number, seed: number) {
  const ground = terrainHeight(tx, tz, seed);
  if (ground <= SEA + 1 || ground > SY - 9) return;
  if (hash01(tx, tz, seed + 90) < 0.992) return;
  if (Math.hypot(tx, tz) < 7) return;
  const trunk = 4 + Math.floor(hash01(tx, tz, seed + 3) * 3);
  const top = ground + trunk;
  for (let y = ground + 1; y <= top; y++) writeLocal(blocks, cx, cz, tx, y, tz, LOG, true);
  for (let y = top - 2; y <= top + 1; y++) {
    const rad = y >= top ? 1 : 2;
    for (let dz = -rad; dz <= rad; dz++) {
      for (let dx = -rad; dx <= rad; dx++) {
        if (dx === 0 && dz === 0 && y <= top) continue;
        if (Math.abs(dx) === 2 && Math.abs(dz) === 2 && hash01(tx + dx, tz + dz, seed + y) < 0.45) continue;
        writeLocal(blocks, cx, cz, tx + dx, y, tz + dz, LEAVES, true);
      }
    }
  }
}

function stampBoulder(blocks: Uint8Array, cx: number, cz: number, tx: number, tz: number, seed: number) {
  const ground = terrainHeight(tx, tz, seed);
  if (ground <= SEA + 1) return;
  if (hash01(tx, tz, seed + 50) < 0.996) return;
  if (Math.hypot(tx, tz) < 8) return;
  writeLocal(blocks, cx, cz, tx, ground + 1, tz, COBBLE, true);
  if (hash01(tx, tz, seed + 51) > 0.5) writeLocal(blocks, cx, cz, tx + 1, ground + 1, tz, COBBLE, true);
  if (hash01(tx, tz, seed + 52) > 0.55) writeLocal(blocks, cx, cz, tx, ground + 2, tz, COBBLE, true);
}

export class World {
  seed: number;
  chunks = new Map<string, Chunk>();
  /** Per-chunk local index → block id differing from generation. */
  edits = new Map<string, Map<number, number>>();
  dirty = new Set<string>();

  constructor(seed: number) {
    this.seed = seed | 0;
  }

  private generate(cx: number, cz: number): Chunk {
    const blocks = new Uint8Array(SX * SY * SZ);
    const x0 = cx * SX;
    const z0 = cz * SZ;
    for (let lz = 0; lz < SZ; lz++) {
      for (let lx = 0; lx < SX; lx++) {
        const x = x0 + lx;
        const z = z0 + lz;
        const h = terrainHeight(x, z, this.seed);
        const shore = h <= SEA + 1;
        for (let y = 0; y <= h; y++) {
          let id = STONE;
          if (y === 0) id = BEDROCK;
          else if (shore && y >= h - 2) id = SAND;
          else if (!shore && y === h) id = GRASS;
          else if (!shore && y >= h - 3) id = DIRT;
          blocks[index(lx, y, lz)] = id;
        }
        if (h < SEA) {
          for (let y = h + 1; y <= SEA; y++) blocks[index(lx, y, lz)] = WATER;
        }
      }
    }
    for (let z = z0 - 2; z < z0 + SZ + 2; z++) {
      for (let x = x0 - 2; x < x0 + SX + 2; x++) {
        stampTree(blocks, cx, cz, x, z, this.seed);
        stampBoulder(blocks, cx, cz, x, z, this.seed);
      }
    }
    const base = blocks.slice();
    const edits = this.edits.get(chunkKey(cx, cz));
    if (edits) {
      for (const [i, id] of edits) blocks[i] = id;
    }
    return { cx, cz, blocks, base };
  }

  ensure(cx: number, cz: number): Chunk {
    const key = chunkKey(cx, cz);
    let chunk = this.chunks.get(key);
    if (!chunk) {
      chunk = this.generate(cx, cz);
      this.chunks.set(key, chunk);
    }
    return chunk;
  }

  drop(cx: number, cz: number) {
    this.chunks.delete(chunkKey(cx, cz));
    this.dirty.delete(chunkKey(cx, cz));
  }

  getBlock(x: number, y: number, z: number): number {
    if (y < 0) return BEDROCK;
    if (y >= SY) return AIR;
    const cx = Math.floor(x / SX);
    const cz = Math.floor(z / SZ);
    const chunk = this.ensure(cx, cz);
    const lx = x - cx * SX;
    const lz = z - cz * SZ;
    return chunk.blocks[index(lx, y, lz)] ?? AIR;
  }

  setBlock(x: number, y: number, z: number, id: number): boolean {
    if (y < 0 || y >= SY) return false;
    const cx = Math.floor(x / SX);
    const cz = Math.floor(z / SZ);
    const chunk = this.ensure(cx, cz);
    const lx = x - cx * SX;
    const lz = z - cz * SZ;
    const i = index(lx, y, lz);
    if (chunk.blocks[i] === id) return false;
    chunk.blocks[i] = id;
    const key = chunkKey(cx, cz);
    let map = this.edits.get(key);
    if (id === chunk.base[i]) {
      map?.delete(i);
      if (map && map.size === 0) this.edits.delete(key);
    } else {
      if (!map) {
        map = new Map();
        this.edits.set(key, map);
      }
      map.set(i, id);
    }
    this.dirty.add(key);
    if (lx === 0) this.dirty.add(chunkKey(cx - 1, cz));
    if (lx === SX - 1) this.dirty.add(chunkKey(cx + 1, cz));
    if (lz === 0) this.dirty.add(chunkKey(cx, cz - 1));
    if (lz === SZ - 1) this.dirty.add(chunkKey(cx, cz + 1));
    return true;
  }

  isSolid(x: number, y: number, z: number): boolean {
    return SOLID[this.getBlock(x, y, z)] === 1;
  }

  exportEdits(): number[] {
    const out: number[] = [];
    for (const [key, map] of this.edits) {
      const comma = key.indexOf(",");
      const cx = Number(key.slice(0, comma));
      const cz = Number(key.slice(comma + 1));
      for (const [i, id] of map) {
        const lx = i % SX;
        const rest = Math.floor(i / SX);
        const y = rest % SY;
        const lz = Math.floor(rest / SY);
        out.push(cx * SX + lx, y, cz * SZ + lz, id);
      }
    }
    return out;
  }

  importEdits(flat: number[]) {
    this.edits.clear();
    for (let n = 0; n + 3 < flat.length; n += 4) {
      const x = flat[n] ?? 0;
      const y = flat[n + 1] ?? 0;
      const z = flat[n + 2] ?? 0;
      const id = flat[n + 3] ?? AIR;
      if (y < 0 || y >= SY) continue;
      const cx = Math.floor(x / SX);
      const cz = Math.floor(z / SZ);
      const lx = x - cx * SX;
      const lz = z - cz * SZ;
      const key = chunkKey(cx, cz);
      let map = this.edits.get(key);
      if (!map) {
        map = new Map();
        this.edits.set(key, map);
      }
      map.set(index(lx, y, lz), id);
    }
  }

  clearChunks() {
    this.chunks.clear();
    this.dirty.clear();
  }
}
