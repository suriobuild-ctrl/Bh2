import { AIR, BEDROCK, OPAQUE, faceShade, faceTile } from "@/game/blocks";
import { SX, SY, SZ, type World } from "@/game/world";
import * as THREE from "three";

type Face = {
  dir: [number, number, number];
  corners: { pos: [number, number, number]; uv: [number, number] }[];
};

// Winding matches the three.js voxel-geometry manual (outward CCW).
const FACES: Face[] = [
  {
    dir: [-1, 0, 0],
    corners: [
      { pos: [0, 1, 0], uv: [0, 1] },
      { pos: [0, 0, 0], uv: [0, 0] },
      { pos: [0, 1, 1], uv: [1, 1] },
      { pos: [0, 0, 1], uv: [1, 0] },
    ],
  },
  {
    dir: [1, 0, 0],
    corners: [
      { pos: [1, 1, 1], uv: [0, 1] },
      { pos: [1, 0, 1], uv: [0, 0] },
      { pos: [1, 1, 0], uv: [1, 1] },
      { pos: [1, 0, 0], uv: [1, 0] },
    ],
  },
  {
    dir: [0, -1, 0],
    corners: [
      { pos: [1, 0, 1], uv: [1, 0] },
      { pos: [0, 0, 1], uv: [0, 0] },
      { pos: [1, 0, 0], uv: [1, 1] },
      { pos: [0, 0, 0], uv: [0, 1] },
    ],
  },
  {
    dir: [0, 1, 0],
    corners: [
      { pos: [0, 1, 1], uv: [1, 1] },
      { pos: [1, 1, 1], uv: [0, 1] },
      { pos: [0, 1, 0], uv: [1, 0] },
      { pos: [1, 1, 0], uv: [0, 0] },
    ],
  },
  {
    dir: [0, 0, -1],
    corners: [
      { pos: [1, 0, 0], uv: [0, 0] },
      { pos: [0, 0, 0], uv: [1, 0] },
      { pos: [1, 1, 0], uv: [0, 1] },
      { pos: [0, 1, 0], uv: [1, 1] },
    ],
  },
  {
    dir: [0, 0, 1],
    corners: [
      { pos: [0, 0, 1], uv: [0, 0] },
      { pos: [1, 0, 1], uv: [1, 0] },
      { pos: [0, 1, 1], uv: [0, 1] },
      { pos: [1, 1, 1], uv: [1, 1] },
    ],
  },
];

const ATLAS = 16;

function tileUV(tile: number, u: number, v: number): [number, number] {
  const inset = 0.06;
  const uu = tile + inset + u * (1 - inset * 2);
  const vv = inset + v * (1 - inset * 2);
  return [uu / ATLAS, vv];
}

type Bucket = {
  positions: number[];
  normals: number[];
  uvs: number[];
  colors: number[];
  indices: number[];
};

function bucket(): Bucket {
  return { positions: [], normals: [], uvs: [], colors: [], indices: [] };
}

function pushFace(b: Bucket, x: number, y: number, z: number, face: Face, tile: number, shade: number) {
  const ndx = b.positions.length / 3;
  const [nx, ny, nz] = face.dir;
  for (const corner of face.corners) {
    b.positions.push(corner.pos[0] + x, corner.pos[1] + y, corner.pos[2] + z);
    b.normals.push(nx, ny, nz);
    const [u, v] = tileUV(tile, corner.uv[0], corner.uv[1]);
    b.uvs.push(u, v);
    b.colors.push(shade, shade, shade);
  }
  b.indices.push(ndx, ndx + 1, ndx + 2, ndx + 2, ndx + 1, ndx + 3);
}

function toGeo(b: Bucket): THREE.BufferGeometry | null {
  if (b.indices.length === 0) return null;
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(b.positions, 3));
  geo.setAttribute("normal", new THREE.Float32BufferAttribute(b.normals, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(b.uvs, 2));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(b.colors, 3));
  geo.setIndex(new THREE.BufferAttribute(new Uint32Array(b.indices), 1));
  geo.computeBoundingSphere();
  return geo;
}

function hidden(selfId: number, neighbor: number, transparent: boolean): boolean {
  if (neighbor === AIR) return false;
  if (!transparent) return OPAQUE[neighbor] === 1;
  if (neighbor === selfId) return true;
  return OPAQUE[neighbor] === 1;
}

export function buildChunkGeometry(world: World, cx: number, cz: number): {
  opaque: THREE.BufferGeometry | null;
  trans: THREE.BufferGeometry | null;
} {
  const chunk = world.ensure(cx, cz);
  const blocks = chunk.blocks;
  const x0 = cx * SX;
  const z0 = cz * SZ;
  const opaque = bucket();
  const trans = bucket();

  const at = (lx: number, y: number, lz: number): number => {
    if (y < 0 || y >= SY) return y < 0 ? BEDROCK : AIR;
    if (lx < 0 || lx >= SX || lz < 0 || lz >= SZ) return world.getBlock(x0 + lx, y, z0 + lz);
    return blocks[lx + SX * (y + SY * lz)] ?? AIR;
  };

  for (let lz = 0; lz < SZ; lz++) {
    for (let lx = 0; lx < SX; lx++) {
      for (let y = 0; y < SY; y++) {
        const id = blocks[lx + SX * (y + SY * lz)] ?? AIR;
        if (id === AIR) continue;
        const transparent = OPAQUE[id] !== 1;
        const dest = transparent ? trans : opaque;
        const wx = x0 + lx;
        const wz = z0 + lz;
        for (const face of FACES) {
          const nx = face.dir[0];
          const ny = face.dir[1];
          const nz = face.dir[2];
          const neighbor = at(lx + nx, y + ny, lz + nz);
          if (hidden(id, neighbor, transparent)) continue;
          pushFace(dest, wx, y, wz, face, faceTile(id, nx, ny, nz), faceShade(nx, ny, nz));
        }
      }
    }
  }

  return { opaque: toGeo(opaque), trans: toGeo(trans) };
}

export function buildHeldGeometry(id: number): THREE.BufferGeometry {
  const opaque = bucket();
  for (const face of FACES) {
    const nx = face.dir[0];
    const ny = face.dir[1];
    const nz = face.dir[2];
    pushFace(opaque, 0, 0, 0, face, faceTile(id, nx, ny, nz), faceShade(nx, ny, nz));
  }
  return toGeo(opaque) ?? new THREE.BoxGeometry(1, 1, 1);
}
