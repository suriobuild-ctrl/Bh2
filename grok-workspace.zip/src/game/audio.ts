export class Sfx {
  private ctx: AudioContext | null = null;

  resume() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, slide = 0) {
    const ctx = this.ctx;
    if (!ctx) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  break() {
    this.tone(180, 0.08, "square", 0.04, -80);
    this.tone(90, 0.12, "triangle", 0.05, -40);
  }

  place() {
    this.tone(420, 0.06, "square", 0.035, 80);
  }

  step() {
    this.tone(120 + Math.random() * 30, 0.04, "triangle", 0.02, -20);
  }

  jump() {
    this.tone(320, 0.07, "square", 0.03, 140);
  }
}
