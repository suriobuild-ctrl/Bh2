import { BLOCKS, HOTBAR, LEAVES, OPAQUE, SOLID } from "@/game/blocks";
import { iconDataURL, makeAtlasCanvas } from "@/game/atlas";
import { Sfx } from "@/game/audio";
import { buildChunkGeometry, buildHeldGeometry } from "@/game/mesh";
import { raycast, type Hit } from "@/game/raycast";
import { clearSave, loadSave, writeSave, type SaveData } from "@/game/save";
import { SX, SY, SZ, World, chunkKey } from "@/game/world";
import * as THREE from "three";

export type Phase = "loading" | "menu" | "play" | "pause";

export type PhaseInfo = {
  phase: Phase;
  hasSave: boolean;
  seed: number;
};

export type HudSnapshot = {
  x: number;
  y: number;
  z: number;
  facing: string;
  slot: number;
  mine: number;
  target: string;
  flying: boolean;
  fps: number;
  debug: boolean;
  debugText: string;
};

export type EngineHooks = {
  onPhase: (info: PhaseInfo) => void;
  onHud: (hud: HudSnapshot) => void;
  onNeedTouch: () => void;
  onFail: (message: string) => void;
};

type Actions = {
  forward: number;
  strafe: number;
  jumpHeld: boolean;
  jumpPressed: boolean;
  sneak: boolean;
  sprint: boolean;
  attack: boolean;
  use: boolean;
  usePressed: boolean;
};

type ChunkMesh = { opaque: THREE.Mesh | null; trans: THREE.Mesh | null };

type Particle = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  size: number;
};

const FACING = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
const REACH = 6;
const HW = 0.28;
const HEIGHT = 1.72;
const EYE = 1.62;

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function radial(x: number, y: number, dz = 0.18) {
  const m = Math.hypot(x, y);
  if (m < dz || m === 0) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export class Engine {
  readonly icons = new Map<number, string>();
  phase: Phase = "loading";
  private dead = false;
  private loopOn = false;
  private raf = 0;
  private hooks: EngineHooks;
  private canvas: HTMLCanvasElement;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private world!: World;
  private sfx = new Sfx();
  private opaqueMat!: THREE.MeshLambertMaterial;
  private transMat!: THREE.MeshLambertMaterial;
  private atlasTex!: THREE.CanvasTexture;
  private meshes = new Map<string, ChunkMesh>();
  private amb!: THREE.AmbientLight;
  private hemi!: THREE.HemisphereLight;
  private sun!: THREE.DirectionalLight;
  private sky = new THREE.Color("#8ec8ea");
  private fog!: THREE.Fog;
  private sunMesh!: THREE.Mesh;
  private moonMesh!: THREE.Mesh;
  private stars!: THREE.Points;
  private cloudMat!: THREE.MeshBasicMaterial;
  private hand!: THREE.Mesh;
  private box!: THREE.LineSegments;
  private particles!: THREE.InstancedMesh;
  private particleData: Particle[] = [];
  private dummy = new THREE.Object3D();
  private lookScratch = new THREE.Vector3();
  private keys = new Set<string>();
  private probeOn = false;
  private probeKeys = new Set<string>();
  private lookDX = 0;
  private lookDY = 0;
  private touchX = 0;
  private touchY = 0;
  private touchJump = false;
  private touchAttack = false;
  private touchUse = false;
  private rmb = false;
  private pcolor = new THREE.Color();
  private attackHeld = false;
  private useHeld = false;
  private prevJump = false;
  private prevUse = false;
  private touchMode = false;
  private sens = 0.00215;
  private invert = false;
  private px = 0.5;
  private py = 30;
  private pz = 0.5;
  private yaw = 0.4;
  private pitch = -0.25;
  private vy = 0;
  private onGround = false;
  private flying = false;
  private coyote = 0;
  private jumpBuf = 0;
  private lastJumpTap = -10;
  private time = 0;
  private acc = 0;
  private speed = 0;
  private slot = 0;
  private mineT = 0;
  private mineX = 99;
  private mineY = 99;
  private mineZ = 99;
  private useTimer = 0;
  private stepAcc = 0;
  private bob = 0;
  private moving = false;
  private swing = 0;
  private shake = 0;
  private sprinting = false;
  private dayT = 0.22;
  private menuAng = 0.6;
  private radius = 3;
  private persisted = false;
  private saveTimer = 0;
  private dirtySave = false;
  private fps = 60;
  private hudTimer = 0;
  private debug = false;
  private lastHud = "";
  private reducedMotion = false;
  private readonly onKeyDown: (e: KeyboardEvent) => void;
  private readonly onKeyUp: (e: KeyboardEvent) => void;
  private readonly onBlur: () => void;
  private readonly onMouseDown: (e: MouseEvent) => void;
  private readonly onMouseUp: (e: MouseEvent) => void;
  private readonly onMouseMove: (e: MouseEvent) => void;
  private readonly onWheel: (e: WheelEvent) => void;
  private readonly onContext: (e: Event) => void;
  private readonly onLockChange: () => void;
  private readonly onLockError: () => void;
  private readonly onResize: () => void;
  private resizeObs: ResizeObserver | null = null;

  constructor(canvas: HTMLCanvasElement, hooks: EngineHooks) {
    this.canvas = canvas;
    this.hooks = hooks;
    this.onKeyDown = (e) => this.keyDown(e);
    this.onKeyUp = (e) => this.keys.delete(e.code);
    this.onBlur = () => this.releaseHeld();
    this.onMouseDown = (e) => this.mouseDown(e);
    this.onMouseUp = (e) => this.mouseUp(e);
    this.onMouseMove = (e) => this.mouseMove(e);
    this.onWheel = (e) => this.wheel(e);
    this.onContext = (e) => e.preventDefault();
    this.onLockChange = () => {};
    this.onLockError = () => this.hooks.onNeedTouch();
    this.onResize = () => this.resize();
  }

  setTouchMode(on: boolean) {
    this.touchMode = on;
  }

  setTouchMove(x: number, y: number) {
    this.touchX = x;
    this.touchY = y;
  }

  setTouchLook(dx: number, dy: number) {
    this.lookDX += dx;
    this.lookDY += dy;
  }

  setTouchButton(which: "jump" | "attack" | "use", down: boolean) {
    if (which === "jump") this.touchJump = down;
    if (which === "attack") this.touchAttack = down;
    if (which === "use") this.touchUse = down;
  }

  selectSlot(i: number) {
    this.slot = ((i % HOTBAR.length) + HOTBAR.length) % HOTBAR.length;
    this.refreshHand();
    this.pushHud(true);
  }

  toggleFly() {
    this.flying = !this.flying;
    this.vy = 0;
    this.pushHud(true);
  }

  setInvert(on: boolean) {
    this.invert = on;
    try {
      localStorage.setItem("blockhold-invert", on ? "1" : "0");
    } catch {
      /* ignore */
    }
  }

  setSens(v: number) {
    this.sens = clamp(v, 0.0008, 0.006);
    try {
      localStorage.setItem("blockhold-sens", String(this.sens));
    } catch {
      /* ignore */
    }
  }

  getSens() {
    return this.sens;
  }

  getInvert() {
    return this.invert;
  }

  requestLook() {
    if (this.phase !== "play" || this.touchMode) return;
    const p = this.canvas.requestPointerLock?.();
    if (p && typeof (p as Promise<void>).catch === "function") {
      void (p as Promise<void>).catch(() => this.hooks.onNeedTouch());
    }
  }

  play() {
    if (this.dead || this.phase === "loading") return;
    this.sfx.resume();
    this.unstick();
    this.phase = "play";
    this.emitPhase();
    this.requestLook();
    this.pushHud(true);
  }

  startFresh(seed: number) {
    if (this.dead) return;
    this.sfx.resume();
    clearSave();
    this.persisted = false;
    this.bootstrap(seed | 0, null);
    const cx = Math.floor(this.px / SX);
    const cz = Math.floor(this.pz / SZ);
    for (let dz = -2; dz <= 2; dz++) {
      for (let dx = -2; dx <= 2; dx++) {
        if (dx * dx + dz * dz > 6) continue;
        this.rebuild(cx + dx, cz + dz);
      }
    }
    this.phase = "play";
    this.emitPhase();
    this.requestLook();
    this.pushHud(true);
  }

  pause() {
    if (this.phase !== "play") return;
    this.phase = "pause";
    this.releaseHeld();
    if (document.pointerLockElement === this.canvas) document.exitPointerLock?.();
    this.saveNow();
    this.emitPhase();
  }

  resume() {
    if (this.phase !== "pause") return;
    this.phase = "play";
    this.emitPhase();
    this.requestLook();
  }

  quit() {
    this.saveNow();
    this.phase = "menu";
    this.releaseHeld();
    if (document.pointerLockElement === this.canvas) document.exitPointerLock?.();
    this.emitPhase();
  }

  async start() {
    try {
      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: false,
        alpha: false,
        powerPreference: "high-performance",
      });
    } catch {
      this.hooks.onFail("This browser couldn't start the 3D world.");
      return;
    }
    if (!this.renderer.getContext()) {
      this.hooks.onFail("This browser couldn't start the 3D world.");
      return;
    }
    const coarse = window.matchMedia("(pointer: coarse), (max-width: 840px)").matches;
    this.radius = coarse ? 2 : 3;
    this.reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    try {
      const sens = Number(localStorage.getItem("blockhold-sens"));
      if (sens > 0) this.sens = clamp(sens, 0.0008, 0.006);
      this.invert = localStorage.getItem("blockhold-invert") === "1";
    } catch {
      /* ignore */
    }
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, coarse ? 1.25 : 1.5));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.scene = new THREE.Scene();
    this.scene.background = this.sky;
    this.fog = new THREE.Fog(this.sky.clone(), this.radius * 10, this.radius * 16 + 10);
    this.scene.fog = this.fog;
    this.camera = new THREE.PerspectiveCamera(72, 1, 0.08, 420);
    this.camera.rotation.order = "YXZ";
    this.resize();
    this.amb = new THREE.AmbientLight(0xffffff, 0.62);
    this.hemi = new THREE.HemisphereLight(0xc5e6ff, 0x6b8a42, 0.42);
    this.sun = new THREE.DirectionalLight(0xfff4dd, 1.05);
    this.sun.position.set(70, 120, 30);
    this.scene.add(this.amb, this.hemi, this.sun);
    this.buildSkyBits();
    const atlas = makeAtlasCanvas();
    this.atlasTex = new THREE.CanvasTexture(atlas);
    this.atlasTex.magFilter = THREE.NearestFilter;
    this.atlasTex.minFilter = THREE.NearestFilter;
    this.atlasTex.colorSpace = THREE.SRGBColorSpace;
    this.atlasTex.generateMipmaps = false;
    this.atlasTex.needsUpdate = true;
    this.opaqueMat = new THREE.MeshLambertMaterial({ map: this.atlasTex, vertexColors: true, alphaTest: 0.45 });
    this.transMat = new THREE.MeshLambertMaterial({
      map: this.atlasTex,
      vertexColors: true,
      transparent: true,
      opacity: 0.82,
      depthWrite: false,
    });
    for (const id of HOTBAR) this.icons.set(id, iconDataURL(id));
    this.hand = new THREE.Mesh(buildHeldGeometry(HOTBAR[0] ?? 1), this.opaqueMat);
    this.hand.scale.setScalar(0.28);
    this.hand.frustumCulled = false;
    this.camera.add(this.hand);
    this.scene.add(this.camera);
    const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.01, 1.01, 1.01));
    this.box = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x111111 }));
    this.box.visible = false;
    this.scene.add(this.box);
    const pgeo = new THREE.BoxGeometry(1, 1, 1);
    const pmat = new THREE.MeshBasicMaterial();
    this.particles = new THREE.InstancedMesh(pgeo, pmat, 48);
    this.particles.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(48 * 3), 3);
    this.particles.frustumCulled = false;
    this.particles.count = 48;
    for (let i = 0; i < 48; i++) this.particleData.push({ x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, size: 0 });
    this.hideParticles();
    this.scene.add(this.particles);
    const saved = loadSave();
    this.persisted = !!saved;
    this.bootstrap(saved?.seed ?? (Math.floor(Math.random() * 900000) + 1000), saved);
    await this.syncDisk(Math.floor(this.px / SX), Math.floor(this.pz / SZ), 2);
    if (this.dead) return;
    this.sanity();
    this.installProbe();
    this.bind();
    this.phase = "menu";
    this.emitPhase();
    this.loopOn = true;
    this.last = performance.now();
    this.frame(0);
    this.raf = requestAnimationFrame(this.loop);
  }

  private last = 0;
  private loop = (now: number) => {
    if (!this.loopOn || this.dead) return;
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.frame(dt);
    this.raf = requestAnimationFrame(this.loop);
  };

  dispose() {
    this.dead = true;
    this.loopOn = false;
    cancelAnimationFrame(this.raf);
    this.unbind();
    this.resizeObs?.disconnect();
    for (const key of [...this.meshes.keys()]) this.disposeChunkMesh(key);
    this.hand?.geometry.dispose();
    this.box?.geometry.dispose();
    (this.box?.material as THREE.Material | undefined)?.dispose();
    this.particles?.geometry.dispose();
    (this.particles?.material as THREE.Material | undefined)?.dispose();
    this.opaqueMat?.dispose();
    this.transMat?.dispose();
    this.atlasTex?.dispose();
    this.cloudMat?.map?.dispose();
    this.cloudMat?.dispose();
    this.renderer?.dispose();
    if (window.__controlsTest) delete window.__controlsTest;
  }

  private bootstrap(seed: number, save: SaveData | null) {
    for (const key of [...this.meshes.keys()]) this.disposeChunkMesh(key);
    this.world = new World(seed);
    if (save) this.world.importEdits(save.edits);
    if (save) {
      this.px = save.player.x;
      this.py = save.player.y;
      this.pz = save.player.z;
      this.yaw = save.player.yaw;
      this.pitch = save.player.pitch;
      this.flying = save.player.flying;
      this.slot = save.player.slot % HOTBAR.length;
    } else {
      const s = this.findSpawn();
      this.px = s.x;
      this.py = s.y;
      this.pz = s.z;
      this.yaw = 0.45;
      this.pitch = -0.22;
      this.flying = false;
      this.slot = 0;
    }
    this.vy = 0;
    this.refreshHand();
  }

  private async syncDisk(cx: number, cz: number, r: number) {
    const list: { cx: number; cz: number; d: number }[] = [];
    for (let dz = -r; dz <= r; dz++) {
      for (let dx = -r; dx <= r; dx++) {
        if (dx * dx + dz * dz > r * r + r) continue;
        list.push({ cx: cx + dx, cz: cz + dz, d: dx * dx + dz * dz });
      }
    }
    list.sort((a, b) => a.d - b.d);
    for (let i = 0; i < list.length; i++) {
      if (this.dead) return;
      const item = list[i];
      if (!item) continue;
      this.rebuild(item.cx, item.cz);
      if (i % 2 === 1) await new Promise((res) => setTimeout(res, 0));
    }
  }

  private sanity() {
    const ground = this.findSpawn();
    const hit = raycast(this.world, ground.x, ground.y + 4, ground.z, 0, -1, 0, 8);
    if (!hit) throw new Error("The valley failed to form.");
    const under = this.world.getBlock(0, Math.floor(ground.y) - 1, 0);
    if (under === 0) throw new Error("Spawn has no ground.");
  }

  private findSpawn() {
    let y = SY - 2;
    for (; y > 1; y--) {
      const id = this.world.getBlock(0, y, 0);
      if (SOLID[id] === 1 && id !== LEAVES) break;
    }
    return { x: 0.5, y: y + 1, z: 0.5 };
  }

  private bind() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onBlur);
    this.canvas.addEventListener("mousedown", this.onMouseDown);
    window.addEventListener("mouseup", this.onMouseUp);
    window.addEventListener("mousemove", this.onMouseMove);
    this.canvas.addEventListener("wheel", this.onWheel, { passive: false });
    this.canvas.addEventListener("contextmenu", this.onContext);
    document.addEventListener("pointerlockerror", this.onLockError);
    window.addEventListener("resize", this.onResize);
    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(this.canvas);
  }

  private unbind() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onBlur);
    this.canvas.removeEventListener("mousedown", this.onMouseDown);
    window.removeEventListener("mouseup", this.onMouseUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    this.canvas.removeEventListener("wheel", this.onWheel);
    this.canvas.removeEventListener("contextmenu", this.onContext);
    document.removeEventListener("pointerlockerror", this.onLockError);
    window.removeEventListener("resize", this.onResize);
  }

  private releaseHeld() {
    this.keys.clear();
    this.attackHeld = false;
    this.useHeld = false;
    this.touchAttack = false;
    this.touchUse = false;
    this.touchJump = false;
    this.touchX = 0;
    this.touchY = 0;
  }

  private keyDown(e: KeyboardEvent) {
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    if (this.phase === "play" || this.phase === "pause") {
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    }
    if (e.code === "Escape" && this.phase === "play") {
      this.pause();
      return;
    }
    if (e.code === "F3") {
      e.preventDefault();
      this.debug = !this.debug;
      this.pushHud(true);
      return;
    }
    if (this.phase !== "play") return;
    this.keys.add(e.code);
    if (e.repeat) return;
    if (e.code.startsWith("Digit")) {
      const n = Number(e.code.slice(5));
      if (n >= 1 && n <= HOTBAR.length) this.selectSlot(n - 1);
    }
  }

  private mouseDown(e: MouseEvent) {
    if (this.phase !== "play") return;
    if (e.button === 0) {
      this.attackHeld = true;
      if (!this.touchMode && document.pointerLockElement !== this.canvas) this.requestLook();
    } else if (e.button === 2) {
      this.useHeld = true;
      this.rmb = true;
    } else if (e.button === 1) {
      e.preventDefault();
      this.pick();
    }
  }

  private mouseUp(e: MouseEvent) {
    if (e.button === 0) this.attackHeld = false;
    if (e.button === 2) {
      this.useHeld = false;
      this.rmb = false;
    }
  }

  private mouseMove(e: MouseEvent) {
    if (document.pointerLockElement === this.canvas || this.rmb) {
      this.lookDX += e.movementX;
      this.lookDY += e.movementY;
    }
  }

  private wheel(e: WheelEvent) {
    if (this.phase !== "play") return;
    e.preventDefault();
    if (e.deltaY > 0) this.selectSlot(this.slot + 1);
    else if (e.deltaY < 0) this.selectSlot(this.slot - 1);
  }

  private resize() {
    const w = this.canvas.clientWidth || 1;
    const h = this.canvas.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  }

  private down(code: string) {
    if (this.probeOn) return this.probeKeys.has(code);
    return this.keys.has(code);
  }

  private sample(): Actions {
    let forward = (this.down("KeyW") || this.down("ArrowUp") ? 1 : 0) - (this.down("KeyS") || this.down("ArrowDown") ? 1 : 0);
    let strafe = (this.down("KeyD") || this.down("ArrowRight") ? 1 : 0) - (this.down("KeyA") || this.down("ArrowLeft") ? 1 : 0);
    let jumpHeld = this.down("Space");
    let sneak = this.down("ShiftLeft") || this.down("ShiftRight");
    let sprint = this.down("ControlLeft") || this.down("ControlRight");
    let attack = false;
    let use = false;
    if (!this.probeOn) {
      forward += this.touchY;
      strafe += this.touchX;
      jumpHeld = jumpHeld || this.touchJump;
      attack = this.attackHeld || this.touchAttack;
      use = this.useHeld || this.touchUse;
      const pads = navigator.getGamepads?.();
      const gp = pads ? pads[0] : null;
      if (gp) {
        const move = radial(gp.axes[0] ?? 0, gp.axes[1] ?? 0, 0.18);
        strafe += move.x;
        forward += -move.y;
        jumpHeld = jumpHeld || !!gp.buttons[0]?.pressed;
        sneak = sneak || !!gp.buttons[1]?.pressed;
        sprint = sprint || !!gp.buttons[10]?.pressed;
        attack = attack || (gp.buttons[7]?.value ?? 0) > 0.4;
        use = use || (gp.buttons[6]?.value ?? 0) > 0.4;
      }
    }
    forward = clamp(forward, -1, 1);
    strafe = clamp(strafe, -1, 1);
    const jumpPressed = jumpHeld && !this.prevJump;
    const usePressed = use && !this.prevUse;
    this.prevJump = jumpHeld;
    this.prevUse = use;
    return { forward, strafe, jumpHeld, jumpPressed, sneak, sprint, attack, use, usePressed };
  }

  private frame(dt: number) {
    this.time += dt;
    this.fps += (1 / Math.max(dt, 0.001) - this.fps) * 0.08;
    if (this.phase === "play") {
      this.yaw -= this.lookDX * this.sens;
      this.pitch = clamp(this.pitch - this.lookDY * this.sens * (this.invert ? -1 : 1), -1.45, 1.45);
      if (this.down("KeyQ")) this.yaw += 1.7 * dt;
      if (this.down("KeyE")) this.yaw -= 1.7 * dt;
      if (!this.probeOn) {
        const pads = navigator.getGamepads?.();
        const gp = pads ? pads[0] : null;
        if (gp) {
          const look = radial(gp.axes[2] ?? 0, gp.axes[3] ?? 0, 0.16);
          this.yaw -= look.x * 2.3 * dt;
          this.pitch = clamp(this.pitch - look.y * 1.8 * dt * (this.invert ? -1 : 1), -1.45, 1.45);
        }
      }
      this.lookDX = 0;
      this.lookDY = 0;
      const actions = this.sample();
      this.sprinting = actions.sprint && actions.forward > 0.2 && !actions.sneak && !this.flying;
      let acc = this.acc + dt;
      let steps = 0;
      let first = true;
      while (acc >= 1 / 60 && steps < 4) {
        this.simulate(1 / 60, actions, first);
        first = false;
        acc -= 1 / 60;
        steps++;
      }
      this.acc = acc > 1 / 60 ? 0 : acc;
      this.interact(dt, actions);
      this.animateBody(dt);
      this.saveTimer += dt;
      if (this.dirtySave && this.saveTimer > 1.6) this.saveNow();
    } else if (this.phase === "menu") {
      if (!this.reducedMotion) this.menuAng += dt * 0.15;
      this.lookDX = 0;
      this.lookDY = 0;
    }
    this.stream();
    this.updateSky(dt);
    this.updateCamera(dt);
    this.updateHand(dt);
    this.updateParticles(dt);
    this.hudTimer += dt;
    if (this.phase === "play" || this.phase === "pause") this.pushHud(false);
    this.renderer.render(this.scene, this.camera);
  }

  private simulate(dt: number, a: Actions, first: boolean) {
    if (first && a.jumpPressed) {
      if (this.time - this.lastJumpTap < 0.28) {
        this.flying = !this.flying;
        this.vy = 0;
        this.jumpBuf = 0;
        this.lastJumpTap = -10;
      } else {
        this.lastJumpTap = this.time;
        this.jumpBuf = 0.14;
      }
    } else if (!a.jumpHeld) {
      this.jumpBuf = Math.max(0, this.jumpBuf - dt);
    }
    if (this.onGround) this.coyote = 0.12;
    else this.coyote = Math.max(0, this.coyote - dt);

    if (!this.flying && (this.jumpBuf > 0 || a.jumpHeld) && (this.onGround || this.coyote > 0)) {
      this.vy = 8.15;
      this.onGround = false;
      this.coyote = 0;
      this.jumpBuf = 0;
      this.sfx.jump();
    }

    if (this.flying) {
      let lift = 0;
      if (a.jumpHeld) lift += 8;
      if (a.sneak) lift -= 8;
      this.moveY(lift * dt);
    } else {
      this.vy = Math.max(-26, this.vy - 28 * dt);
      this.onGround = false;
      this.moveY(this.vy * dt);
      if (this.vy === 0 && this.grounded()) this.onGround = true;
    }

    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw);
    const rz = -Math.sin(this.yaw);
    let mx = fx * a.forward + rx * a.strafe;
    let mz = fz * a.forward + rz * a.strafe;
    const mag = Math.hypot(mx, mz);
    let speed = 4.55;
    if (this.flying) speed = 11.2;
    else if (this.sprinting) speed = 7.15;
    else if (a.sneak) speed = 1.75;
    if (mag > 1) {
      mx /= mag;
      mz /= mag;
    }
    const ox = this.px;
    const oz = this.pz;
    this.moveAxis("x", mx * speed * dt);
    this.moveAxis("z", mz * speed * dt);
    const dist = Math.hypot(this.px - ox, this.pz - oz);
    this.speed = dist / dt;
    this.moving = this.speed > 0.4;
    if (this.onGround && !this.flying && this.moving) {
      this.stepAcc += dist;
      if (this.stepAcc > 2.15) {
        this.stepAcc = 0;
        this.sfx.step();
      }
    }
    if (this.py < -8) {
      const s = this.findSpawn();
      this.px = s.x;
      this.py = s.y + 1;
      this.pz = s.z;
      this.vy = 0;
    }
  }

  private grounded() {
    this.py -= 0.08;
    const hit = this.overlapsAt(this.px, this.py, this.pz);
    this.py += 0.08;
    return hit;
  }

  private overlapsAt(px: number, py: number, pz: number) {
    const eps = 0.001;
    const minX = Math.floor(px - HW + eps);
    const maxX = Math.floor(px + HW - eps);
    const minY = Math.floor(py + eps);
    const maxY = Math.floor(py + HEIGHT - eps);
    const minZ = Math.floor(pz - HW + eps);
    const maxZ = Math.floor(pz + HW - eps);
    for (let y = minY; y <= maxY; y++) {
      for (let z = minZ; z <= maxZ; z++) {
        for (let x = minX; x <= maxX; x++) {
          if (SOLID[this.world.getBlock(x, y, z)] === 1) return true;
        }
      }
    }
    return false;
  }

  private moveAxis(axis: "x" | "z", amount: number) {
    if (amount === 0) return;
    const sign = Math.sign(amount);
    let left = Math.abs(amount);
    while (left > 0) {
      const step = Math.min(0.18, left);
      if (axis === "x") this.px += sign * step;
      else this.pz += sign * step;
      if (this.overlapsAt(this.px, this.py, this.pz)) {
        if (axis === "x") this.px -= sign * step;
        else this.pz -= sign * step;
        let nib = step * 0.5;
        while (nib > 0.002) {
          if (axis === "x") this.px += sign * nib;
          else this.pz += sign * nib;
          if (this.overlapsAt(this.px, this.py, this.pz)) {
            if (axis === "x") this.px -= sign * nib;
            else this.pz -= sign * nib;
          }
          nib *= 0.5;
        }
        return;
      }
      left -= step;
    }
  }

  private moveY(amount: number) {
    if (amount === 0) return;
    const sign = Math.sign(amount);
    let left = Math.abs(amount);
    while (left > 0) {
      const step = Math.min(0.18, left);
      this.py += sign * step;
      if (this.overlapsAt(this.px, this.py, this.pz)) {
        this.py -= sign * step;
        let nib = step * 0.5;
        while (nib > 0.002) {
          this.py += sign * nib;
          if (this.overlapsAt(this.px, this.py, this.pz)) this.py -= sign * nib;
          nib *= 0.5;
        }
        if (sign < 0) this.onGround = true;
        this.vy = 0;
        return;
      }
      left -= step;
    }
  }

  private unstick() {
    let guard = 0;
    while (this.overlapsAt(this.px, this.py, this.pz) && guard < 32) {
      this.py += 0.25;
      guard++;
    }
  }

  private interact(dt: number, a: Actions) {
    const cp = Math.cos(this.pitch);
    const dx = -Math.sin(this.yaw) * cp;
    const dy = Math.sin(this.pitch);
    const dz = -Math.cos(this.yaw) * cp;
    const eyeY = this.py + (a.sneak && !this.flying ? 1.42 : EYE);
    const hit = raycast(this.world, this.px, eyeY, this.pz, dx, dy, dz, REACH);
    if (!hit || hit.dist <= 0 && hit.nx === 0 && hit.ny === 0 && hit.nz === 0) {
      this.box.visible = false;
      this.mineT = 0;
    } else {
      this.box.visible = true;
      this.box.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
    }
    const target = hit && hit.id ? BLOCKS[hit.id] : undefined;
    if (a.attack && target && target.hard < Infinity && hit) {
      if (hit.x !== this.mineX || hit.y !== this.mineY || hit.z !== this.mineZ) {
        this.mineX = hit.x;
        this.mineY = hit.y;
        this.mineZ = hit.z;
        this.mineT = 0;
      }
      this.mineT += dt;
      if (this.mineT >= target.hard) {
        this.world.setBlock(hit.x, hit.y, hit.z, 0);
        this.burst(hit, target.rgb);
        this.sfx.break();
        this.shake = Math.min(0.08, this.shake + 0.045);
        this.swing = 1;
        this.mineT = 0;
        this.dirtySave = true;
      }
    } else {
      this.mineT = 0;
    }
    if (a.use && hit) {
      this.useTimer = a.usePressed ? 0 : this.useTimer - dt;
      if (a.usePressed || this.useTimer <= 0) {
        this.tryPlace(hit);
        this.useTimer = 0.22;
      }
    } else this.useTimer = 0;
    void target;
  }

  private tryPlace(hit: Hit) {
    if (hit.nx === 0 && hit.ny === 0 && hit.nz === 0) return;
    const x = hit.x + hit.nx;
    const y = hit.y + hit.ny;
    const z = hit.z + hit.nz;
    const id = HOTBAR[this.slot] ?? 0;
    if (!id) return;
    if (y < 0 || y >= SY) return;
    if (this.world.getBlock(x, y, z) !== 0) return;
    if (this.blockHitsPlayer(x, y, z)) return;
    if (this.world.setBlock(x, y, z, id)) {
      this.sfx.place();
      this.swing = 1;
      this.dirtySave = true;
    }
  }

  private blockHitsPlayer(bx: number, by: number, bz: number) {
    return (
      this.px + HW > bx &&
      this.px - HW < bx + 1 &&
      this.py + HEIGHT > by &&
      this.py < by + 1 &&
      this.pz + HW > bz &&
      this.pz - HW < bz + 1
    );
  }

  private pick() {
    const cp = Math.cos(this.pitch);
    const hit = raycast(
      this.world,
      this.px,
      this.py + EYE,
      this.pz,
      -Math.sin(this.yaw) * cp,
      Math.sin(this.pitch),
      -Math.cos(this.yaw) * cp,
      REACH,
    );
    if (!hit) return;
    const idx = HOTBAR.indexOf(hit.id);
    if (idx >= 0) this.selectSlot(idx);
  }

  private animateBody(dt: number) {
    if (this.moving && this.onGround && !this.reducedMotion) this.bob += dt * this.speed * 1.35;
    this.shake = Math.max(0, this.shake - dt * 0.35);
  }

  private stream() {
    const anchorX = this.phase === "menu" ? 0 : this.px;
    const anchorZ = this.phase === "menu" ? 0 : this.pz;
    const pcx = Math.floor(anchorX / SX);
    const pcz = Math.floor(anchorZ / SZ);
    const R = this.radius;
    const needed: { cx: number; cz: number; d: number }[] = [];
    for (let dz = -R; dz <= R; dz++) {
      for (let dx = -R; dx <= R; dx++) {
        if (dx * dx + dz * dz > R * R + R) continue;
        const cx = pcx + dx;
        const cz = pcz + dz;
        const key = chunkKey(cx, cz);
        if (!this.meshes.has(key) || this.world.dirty.has(key)) needed.push({ cx, cz, d: dx * dx + dz * dz });
      }
    }
    needed.sort((a, b) => a.d - b.d);
    const budget = 2;
    for (let i = 0; i < Math.min(budget, needed.length); i++) {
      const n = needed[i];
      if (n) this.rebuild(n.cx, n.cz);
    }
    for (const key of this.meshes.keys()) {
      const comma = key.indexOf(",");
      const cx = Number(key.slice(0, comma));
      const cz = Number(key.slice(comma + 1));
      const dx = cx - pcx;
      const dz = cz - pcz;
      if (dx * dx + dz * dz > (R + 2) * (R + 2)) {
        this.disposeChunkMesh(key);
        this.world.drop(cx, cz);
      }
    }
    for (const key of this.world.chunks.keys()) {
      if (this.meshes.has(key)) continue;
      const comma = key.indexOf(",");
      const cx = Number(key.slice(0, comma));
      const cz = Number(key.slice(comma + 1));
      const dx = cx - pcx;
      const dz = cz - pcz;
      if (dx * dx + dz * dz > (R + 2) * (R + 2)) this.world.drop(cx, cz);
    }
  }

  private rebuild(cx: number, cz: number) {
    const key = chunkKey(cx, cz);
    this.disposeChunkMesh(key);
    const built = buildChunkGeometry(this.world, cx, cz);
    const rec: ChunkMesh = { opaque: null, trans: null };
    if (built.opaque) {
      rec.opaque = new THREE.Mesh(built.opaque, this.opaqueMat);
      this.scene.add(rec.opaque);
    }
    if (built.trans) {
      rec.trans = new THREE.Mesh(built.trans, this.transMat);
      rec.trans.renderOrder = 2;
      this.scene.add(rec.trans);
    }
    this.meshes.set(key, rec);
    this.world.dirty.delete(key);
  }

  private disposeChunkMesh(key: string) {
    const rec = this.meshes.get(key);
    if (!rec) return;
    if (rec.opaque) {
      this.scene.remove(rec.opaque);
      rec.opaque.geometry.dispose();
    }
    if (rec.trans) {
      this.scene.remove(rec.trans);
      rec.trans.geometry.dispose();
    }
    this.meshes.delete(key);
  }

  private updateSky(dt: number) {
    if (this.phase !== "pause") this.dayT = (this.dayT + dt / 720) % 1;
    const elev = Math.sin(this.dayT * Math.PI * 2);
    const ang = this.dayT * Math.PI * 2;
    this.sun.position.set(Math.cos(ang) * 140, elev * 140, 40);
    const day = clamp((elev + 0.08) / 0.7, 0, 1);
    const dusk = clamp(1 - Math.abs(elev) / 0.28, 0, 1) * 0.75;
    this.sky.setRGB(0.07 + day * 0.42 + dusk * 0.55, 0.1 + day * 0.62 + dusk * 0.28, 0.18 + day * 0.78);
    if (this.scene.background instanceof THREE.Color) this.scene.background.copy(this.sky);
    this.fog.color.copy(this.sky);
    this.fog.near = this.radius * 9;
    this.fog.far = this.radius * 16 + 8;
    this.sun.intensity = 0.15 + clamp(elev, 0, 1) * 1.15;
    this.amb.intensity = 0.28 + clamp(elev, 0, 1) * 0.42;
    this.hemi.intensity = 0.18 + clamp(elev, 0, 1) * 0.32;
    this.sunMesh.position.copy(this.sun.position).setLength(180);
    this.moonMesh.position.copy(this.sun.position).multiplyScalar(-1).setLength(180);
    this.sunMesh.visible = elev > -0.05;
    this.moonMesh.visible = elev < 0.2;
    const starMat = this.stars.material as THREE.PointsMaterial;
    starMat.opacity = clamp(-elev * 1.4, 0, 1);
    this.stars.visible = starMat.opacity > 0.02;
    if (this.cloudMat.map && !this.reducedMotion) this.cloudMat.map.offset.x += dt * 0.003;
  }

  private updateCamera(dt: number) {
    const sprintFov = this.sprinting ? 80 : 72;
    if (Math.abs(this.camera.fov - sprintFov) > 0.05) {
      this.camera.fov += (sprintFov - this.camera.fov) * Math.min(1, dt * 6);
      this.camera.updateProjectionMatrix();
    }
    if (this.phase === "menu") {
      this.hand.visible = false;
      this.box.visible = false;
      this.camera.position.set(Math.sin(this.menuAng) * 28, 34, Math.cos(this.menuAng) * 28);
      this.camera.lookAt(1, 18, 0);
      return;
    }
    this.hand.visible = true;
    const sneak = (this.down("ShiftLeft") || this.down("ShiftRight")) && !this.flying;
    const bobY = this.reducedMotion || !this.onGround ? 0 : Math.sin(this.bob) * (this.moving ? 0.045 : 0);
    const jx = (Math.random() - 0.5) * this.shake;
    const jy = (Math.random() - 0.5) * this.shake;
    this.camera.position.set(this.px + jx, this.py + (sneak ? 1.45 : EYE) + bobY + jy, this.pz);
    this.camera.rotation.order = "YXZ";
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;
    this.camera.rotation.z = 0;
  }

  private updateHand(dt: number) {
    this.swing = Math.max(0, this.swing - dt * 3.4);
    const bob = this.reducedMotion ? 0 : Math.sin(this.bob) * (this.moving ? 0.035 : 0);
    this.hand.position.set(0.46, -0.42 + bob, -0.68);
    this.hand.rotation.set(-0.42 - this.swing * 0.9, 0.52, 0.18 + this.swing * 0.35);
  }

  private refreshHand() {
    if (!this.hand) return;
    const id = HOTBAR[this.slot] ?? 1;
    this.hand.geometry.dispose();
    this.hand.geometry = buildHeldGeometry(id);
    this.hand.material = OPAQUE[id] ? this.opaqueMat : this.transMat;
  }

  private burst(hit: Hit, rgb: [number, number, number]) {
    for (let n = 0; n < 8; n++) {
      const i = this.particleData.findIndex((p) => p.life <= 0);
      if (i < 0) return;
      const p = this.particleData[i];
      if (!p) return;
      p.x = hit.x + 0.2 + Math.random() * 0.6;
      p.y = hit.y + 0.2 + Math.random() * 0.6;
      p.z = hit.z + 0.2 + Math.random() * 0.6;
      p.vx = (Math.random() - 0.5) * 3.2;
      p.vy = 1.5 + Math.random() * 2.4;
      p.vz = (Math.random() - 0.5) * 3.2;
      p.size = 0.1 + Math.random() * 0.06;
      p.life = 0.45 + Math.random() * 0.2;
      this.pcolor.setRGB(rgb[0], rgb[1], rgb[2]);
      this.particles.setColorAt(i, this.pcolor);
    }
    if (this.particles.instanceColor) this.particles.instanceColor.needsUpdate = true;
  }

  private updateParticles(dt: number) {
    let alive = false;
    for (let i = 0; i < this.particleData.length; i++) {
      const p = this.particleData[i];
      if (!p || p.life <= 0) {
        this.dummy.position.set(0, -100, 0);
        this.dummy.scale.setScalar(0);
      } else {
        alive = true;
        p.life -= dt;
        p.vy -= 12 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.z += p.vz * dt;
        this.dummy.position.set(p.x, p.y, p.z);
        this.dummy.scale.setScalar(p.life > 0 ? p.size : 0);
      }
      this.dummy.updateMatrix();
      this.particles.setMatrixAt(i, this.dummy.matrix);
    }
    this.particles.instanceMatrix.needsUpdate = alive;
    this.particles.visible = alive;
  }

  private hideParticles() {
    for (let i = 0; i < 48; i++) {
      this.dummy.position.set(0, -80, 0);
      this.dummy.scale.setScalar(0);
      this.dummy.updateMatrix();
      this.particles.setMatrixAt(i, this.dummy.matrix);
    }
    this.particles.instanceMatrix.needsUpdate = true;
    this.particles.visible = false;
  }

  private facing() {
    const compass = ((-this.yaw) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    return FACING[Math.round(compass / (Math.PI / 4)) % 8] ?? "N";
  }

  private pushHud(force: boolean) {
    if (!force && this.hudTimer < 0.1) return;
    this.hudTimer = 0;
    const targetId = this.box.visible ? this.world.getBlock(Math.floor(this.box.position.x), Math.floor(this.box.position.y), Math.floor(this.box.position.z)) : 0;
    const hard = BLOCKS[targetId]?.hard ?? 1;
    const mine = hard > 0 && hard < Infinity && this.mineT > 0 ? clamp(this.mineT / hard, 0, 1) : 0;
    const hud: HudSnapshot = {
      x: Math.floor(this.px),
      y: Math.floor(this.py),
      z: Math.floor(this.pz),
      facing: this.facing(),
      slot: this.slot,
      mine,
      target: targetId ? (BLOCKS[targetId]?.name ?? "") : "",
      flying: this.flying,
      fps: Math.round(this.fps),
      debug: this.debug,
      debugText: this.debug ? `fps ${Math.round(this.fps)}\nchunks ${this.meshes.size}\nseed ${this.world.seed}` : "",
    };
    const key = `${hud.x}|${hud.y}|${hud.z}|${hud.facing}|${hud.slot}|${mine.toFixed(2)}|${hud.target}|${hud.flying}|${hud.debug}|${hud.debugText}`;
    if (!force && key === this.lastHud) return;
    this.lastHud = key;
    this.hooks.onHud(hud);
  }

  private emitPhase() {
    this.hooks.onPhase({ phase: this.phase, hasSave: this.persisted, seed: this.world.seed });
  }

  private saveNow() {
    this.saveTimer = 0;
    this.dirtySave = false;
    const data: SaveData = {
      v: 1,
      seed: this.world.seed,
      edits: this.world.exportEdits(),
      player: {
        x: this.px,
        y: this.py,
        z: this.pz,
        yaw: this.yaw,
        pitch: this.pitch,
        flying: this.flying,
        slot: this.slot,
      },
    };
    writeSave(data);
    this.persisted = true;
  }

  private buildSkyBits() {
    const sunGeo = new THREE.SphereGeometry(9, 16, 12);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xffe7a8, fog: false });
    this.sunMesh = new THREE.Mesh(sunGeo, sunMat);
    const moonMat = new THREE.MeshBasicMaterial({ color: 0xdfe7f2, fog: false });
    this.moonMesh = new THREE.Mesh(new THREE.SphereGeometry(6, 16, 12), moonMat);
    this.scene.add(this.sunMesh, this.moonMesh);
    const starPositions: number[] = [];
    for (let i = 0; i < 280; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const r = 200;
      starPositions.push(r * Math.sin(phi) * Math.cos(theta), r * Math.cos(phi), r * Math.sin(phi) * Math.sin(theta));
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute("position", new THREE.Float32BufferAttribute(starPositions, 3));
    this.stars = new THREE.Points(
      sg,
      new THREE.PointsMaterial({ color: 0xffffff, size: 1.4, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false }),
    );
    this.scene.add(this.stars);
    const c = document.createElement("canvas");
    c.width = 256;
    c.height = 256;
    const g = c.getContext("2d");
    if (g) {
      g.clearRect(0, 0, 256, 256);
      for (let i = 0; i < 18; i++) {
        const x = Math.random() * 256;
        const y = Math.random() * 256;
        const rad = 18 + Math.random() * 36;
        g.fillStyle = `rgba(255,255,255,${0.35 + Math.random() * 0.4})`;
        g.beginPath();
        g.ellipse(x, y, rad, rad * 0.55, Math.random(), 0, Math.PI * 2);
        g.fill();
      }
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(5, 5);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.cloudMat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.55, depthWrite: false, fog: true });
    const clouds = new THREE.Mesh(new THREE.PlaneGeometry(420, 420), this.cloudMat);
    clouds.rotation.x = -Math.PI / 2;
    clouds.position.y = 62;
    this.scene.add(clouds);
  }

  private installProbe() {
    const engine = this;
    window.__controlsTest = {
      getYaw: () => engine.yaw,
      getPitch: () => engine.pitch,
      getSpeed: () => engine.speed,
      getPos: () => ({ x: engine.px, y: engine.py, z: engine.pz }),
      getLook: () => {
        engine.camera.getWorldDirection(engine.lookScratch);
        return { x: engine.lookScratch.x, y: engine.lookScratch.y, z: engine.lookScratch.z };
      },
      setKeys: (codes: string[]) => {
        engine.probeOn = true;
        engine.probeKeys = new Set(codes);
      },
      setYaw: (y: number) => {
        engine.yaw = y;
      },
      setPitch: (p: number) => {
        engine.pitch = p;
      },
      setFlying: (v: boolean) => {
        engine.flying = v;
        engine.vy = 0;
      },
      teleport: (x: number, y: number, z: number) => {
        engine.px = x;
        engine.py = y;
        engine.pz = z;
        engine.vy = 0;
      },
      getBlock: (x: number, y: number, z: number) => engine.world.getBlock(x, y, z),
      setBlock: (x: number, y: number, z: number, id: number) => {
        engine.world.setBlock(x, y, z, id);
      },
      getPhase: () => engine.phase,
    };
  }
}

export type ControlsProbe = {
  getYaw: () => number;
  getPitch: () => number;
  getSpeed: () => number;
  getPos: () => { x: number; y: number; z: number };
  getLook: () => { x: number; y: number; z: number };
  setKeys: (codes: string[]) => void;
  setYaw: (y: number) => void;
  setPitch: (p: number) => void;
  setFlying: (v: boolean) => void;
  teleport: (x: number, y: number, z: number) => void;
  getBlock: (x: number, y: number, z: number) => number;
  setBlock: (x: number, y: number, z: number, id: number) => void;
  getPhase: () => string;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
  }
}
