export const AIR = 0;
export const GRASS = 1;
export const DIRT = 2;
export const STONE = 3;
export const SAND = 4;
export const LOG = 5;
export const LEAVES = 6;
export const WATER = 7;
export const PLANKS = 8;
export const COBBLE = 9;
export const BEDROCK = 10;
export const GLASS = 11;

export const TILE_COUNT = 16;

export const TILE = {
  grassTop: 0,
  grassSide: 1,
  dirt: 2,
  stone: 3,
  sand: 4,
  logSide: 5,
  logTop: 6,
  leaves: 7,
  water: 8,
  planks: 9,
  cobble: 10,
  bedrock: 11,
  glass: 12,
} as const;

export type BlockDef = {
  id: number;
  name: string;
  solid: boolean;
  opaque: boolean;
  hard: number;
  top: number;
  side: number;
  bottom: number;
  rgb: [number, number, number];
};

export const BLOCKS: BlockDef[] = [
  { id: AIR, name: "Air", solid: false, opaque: false, hard: 0, top: 0, side: 0, bottom: 0, rgb: [0, 0, 0] },
  { id: GRASS, name: "Grass", solid: true, opaque: true, hard: 0.32, top: TILE.grassTop, side: TILE.grassSide, bottom: TILE.dirt, rgb: [0.37, 0.65, 0.23] },
  { id: DIRT, name: "Dirt", solid: true, opaque: true, hard: 0.32, top: TILE.dirt, side: TILE.dirt, bottom: TILE.dirt, rgb: [0.55, 0.38, 0.25] },
  { id: STONE, name: "Stone", solid: true, opaque: true, hard: 0.85, top: TILE.stone, side: TILE.stone, bottom: TILE.stone, rgb: [0.55, 0.55, 0.55] },
  { id: SAND, name: "Sand", solid: true, opaque: true, hard: 0.28, top: TILE.sand, side: TILE.sand, bottom: TILE.sand, rgb: [0.89, 0.82, 0.54] },
  { id: LOG, name: "Log", solid: true, opaque: true, hard: 0.55, top: TILE.logTop, side: TILE.logSide, bottom: TILE.logTop, rgb: [0.42, 0.29, 0.16] },
  { id: LEAVES, name: "Leaves", solid: true, opaque: true, hard: 0.22, top: TILE.leaves, side: TILE.leaves, bottom: TILE.leaves, rgb: [0.25, 0.56, 0.2] },
  { id: WATER, name: "Water", solid: true, opaque: false, hard: 0.18, top: TILE.water, side: TILE.water, bottom: TILE.water, rgb: [0.23, 0.49, 0.78] },
  { id: PLANKS, name: "Planks", solid: true, opaque: true, hard: 0.48, top: TILE.planks, side: TILE.planks, bottom: TILE.planks, rgb: [0.77, 0.63, 0.35] },
  { id: COBBLE, name: "Cobble", solid: true, opaque: true, hard: 0.9, top: TILE.cobble, side: TILE.cobble, bottom: TILE.cobble, rgb: [0.45, 0.45, 0.45] },
  { id: BEDROCK, name: "Bedrock", solid: true, opaque: true, hard: Infinity, top: TILE.bedrock, side: TILE.bedrock, bottom: TILE.bedrock, rgb: [0.15, 0.15, 0.15] },
  { id: GLASS, name: "Glass", solid: true, opaque: false, hard: 0.2, top: TILE.glass, side: TILE.glass, bottom: TILE.glass, rgb: [0.75, 0.9, 0.95] },
];

export const HOTBAR: number[] = [GRASS, DIRT, STONE, COBBLE, SAND, LOG, PLANKS, GLASS, WATER];

export const SOLID = new Uint8Array(BLOCKS.map((b) => (b.solid ? 1 : 0)));
export const OPAQUE = new Uint8Array(BLOCKS.map((b) => (b.opaque ? 1 : 0)));

export function faceTile(id: number, nx: number, ny: number, nz: number): number {
  const b = BLOCKS[id] ?? BLOCKS[0];
  if (ny > 0) return b.top;
  if (ny < 0) return b.bottom;
  void nz;
  void nx;
  return b.side;
}

export function faceShade(nx: number, ny: number, nz: number): number {
  if (ny > 0) return 1;
  if (ny < 0) return 0.52;
  if (nx !== 0) return 0.78;
  void nz;
  return 0.64;
}
