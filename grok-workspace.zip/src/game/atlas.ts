import { BLOCKS, TILE_COUNT, faceTile } from "@/game/blocks";

const TILE = 16;

function rgba(hex: number, a = 255): [number, number, number, number] {
  return [(hex >> 16) & 255, (hex >> 8) & 255, hex & 255, a];
}

function mix(a: number, b: number, t: number): number {
  const ar = (a >> 16) & 255;
  const ag = (a >> 8) & 255;
  const ab = a & 255;
  const br = (b >> 16) & 255;
  const bg = (b >> 8) & 255;
  const bb = b & 255;
  const r = (ar + (br - ar) * t) | 0;
  const g = (ag + (bg - ag) * t) | 0;
  const bl = (ab + (bb - ab) * t) | 0;
  return (r << 16) | (g << 8) | bl;
}

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (Math.imul(a ^ (a >>> 15), 1 | a) + 0x6d2b79f5) >>> 0;
    return a / 4294967296;
  };
}

type Spec = { base: number; alt: number; alpha?: number; kind: string };

const SPECS: Record<number, Spec> = {
  0: { base: 0x5ea63a, alt: 0x3e8a28, kind: "grassTop" },
  1: { base: 0x8d6240, alt: 0x6e4a2c, kind: "grassSide" },
  2: { base: 0x8d6240, alt: 0x6b4528, kind: "speck" },
  3: { base: 0x8a8a8a, alt: 0x6e6e6e, kind: "stone" },
  4: { base: 0xe6d48a, alt: 0xcbb86a, kind: "speck" },
  5: { base: 0x6b4a2a, alt: 0x4a3018, kind: "bark" },
  6: { base: 0xc4a05a, alt: 0x8d6232, kind: "rings" },
  7: { base: 0x3f8f32, alt: 0x2d6b22, kind: "leaves" },
  8: { base: 0x3a7ec8, alt: 0x2a62a8, kind: "water" },
  9: { base: 0xc4a05a, alt: 0xa8843e, kind: "planks" },
  10: { base: 0x7a7a7a, alt: 0x5a5a5a, kind: "cobble" },
  11: { base: 0x2a2a2a, alt: 0x111111, kind: "bedrock" },
  12: { base: 0xd5eef5, alt: 0xffffff, kind: "glass" },
};

let atlasCanvas: HTMLCanvasElement | null = null;
const tileCache = new Map<number, Uint8ClampedArray>();

export function makeAtlasCanvas(): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = TILE * TILE_COUNT;
  canvas.height = TILE;
  const g = canvas.getContext("2d");
  if (!g) throw new Error("Could not draw block textures");
  const img = g.createImageData(canvas.width, canvas.height);
  const data = img.data;
  for (let tile = 0; tile < 13; tile++) {
    const spec = SPECS[tile];
    if (!spec) continue;
    const rand = rng(1000 + tile * 97);
    for (let y = 0; y < TILE; y++) {
      for (let x = 0; x < TILE; x++) {
        const px = paintPixel(spec, x, y, rand);
        const o = ((y * canvas.width + tile * TILE + x) * 4) | 0;
        data[o] = px[0];
        data[o + 1] = px[1];
        data[o + 2] = px[2];
        data[o + 3] = px[3];
      }
    }
  }
  g.putImageData(img, 0, 0);
  atlasCanvas = canvas;
  tileCache.clear();
  return canvas;
}

function paintPixel(spec: Spec, x: number, y: number, rand: () => number): [number, number, number, number] {
  const n = rand();
  if (spec.kind === "grassSide") {
    const fringe = y < 3 || (y < 5 && (x + y) % 3 === 0);
    const col = fringe ? mix(0x5ea63a, 0x3e8a28, n) : mix(spec.base, spec.alt, n);
    return rgba(col);
  }
  if (spec.kind === "bark") {
    const stripe = x % 4 === 0 || x % 4 === 1;
    return rgba(stripe ? spec.alt : mix(spec.base, spec.alt, n * 0.45));
  }
  if (spec.kind === "rings") {
    const dx = x - 7.5;
    const dy = y - 7.5;
    const ring = Math.floor(Math.hypot(dx, dy));
    return rgba(ring % 3 === 0 ? spec.alt : spec.base);
  }
  if (spec.kind === "leaves") {
    if ((x + y) % 5 === 0 || n > 0.86) return [0, 0, 0, 0];
    return rgba(n > 0.5 ? spec.base : spec.alt);
  }
  if (spec.kind === "water") {
    const wave = y % 5 === 0;
    const col = wave ? 0x8fd0f2 : mix(spec.base, spec.alt, n * 0.5);
    return rgba(col, wave ? 210 : 185);
  }
  if (spec.kind === "planks") {
    const gap = y % 4 === 3;
    return rgba(gap ? spec.alt : mix(spec.base, 0xe6c98a, n * 0.35));
  }
  if (spec.kind === "cobble") {
    const edge = x % 5 === 0 || y % 4 === 0;
    return rgba(edge ? spec.alt : mix(spec.base, 0x9a9a9a, n * 0.6));
  }
  if (spec.kind === "bedrock") {
    return rgba(n > 0.7 ? spec.base : spec.alt);
  }
  if (spec.kind === "glass") {
    const rim = x === 0 || y === 0 || x === 15 || y === 15 || x === 1 || y === 1;
    if (rim) return rgba(0xeef8ff, 210);
    if (n > 0.92) return rgba(0xffffff, 160);
    return rgba(0xd5eef5, 70);
  }
  if (spec.kind === "stone") {
    const crack = (x + y * 3) % 11 === 0;
    return rgba(crack ? spec.alt : mix(spec.base, 0xb0b0b0, n * 0.55));
  }
  return rgba(n > 0.72 ? spec.alt : mix(spec.base, spec.alt, n * 0.4));
}

function tilePixels(tile: number): Uint8ClampedArray {
  const cached = tileCache.get(tile);
  if (cached) return cached;
  if (!atlasCanvas) throw new Error("Atlas not ready");
  const g = atlasCanvas.getContext("2d");
  if (!g) throw new Error("Atlas not ready");
  const data = g.getImageData(tile * TILE, 0, TILE, TILE).data;
  tileCache.set(tile, data);
  return data;
}

export function iconDataURL(id: number): string {
  const canvas = document.createElement("canvas");
  canvas.width = 96;
  canvas.height = 96;
  const ctx = canvas.getContext("2d");
  if (!ctx || !BLOCKS[id]) return "";
  ctx.imageSmoothingEnabled = false;
  const top = tilePixels(faceTile(id, 0, 1, 0));
  const side = tilePixels(faceTile(id, 1, 0, 0));
  const s = 3;
  const ox = 48;
  const oy = 8;
  const put = (src: Uint8ClampedArray, tx: number, ty: number, sx: number, sy: number, shade: number) => {
    const o = (ty * 16 + tx) * 4;
    const a = src[o + 3] ?? 0;
    if (a < 8) return;
    const r = Math.min(255, ((src[o] ?? 0) * shade) | 0);
    const g = Math.min(255, ((src[o + 1] ?? 0) * shade) | 0);
    const b = Math.min(255, ((src[o + 2] ?? 0) * shade) | 0);
    ctx.fillStyle = `rgba(${r},${g},${b},${a / 255})`;
    ctx.fillRect(sx | 0, sy | 0, s, Math.ceil(s * 0.5) + 1);
  };
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      put(side, x, y, ox - 16 * s + x * s, oy + 8 * s + y * s * 0.72 + (15 - x) * s * 0.28, 0.72);
    }
  }
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      put(side, x, y, ox + x * s, oy + 8 * s + y * s * 0.72 + x * s * 0.28, 0.55);
    }
  }
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const px = ox + (x - y) * s;
      const py = oy + (x + y) * s * 0.5;
      const o = (y * 16 + x) * 4;
      const a = top[o + 3] ?? 0;
      if (a < 8) continue;
      ctx.fillStyle = `rgba(${top[o]},${top[o + 1]},${top[o + 2]},${a / 255})`;
      ctx.fillRect(px, py, s, Math.ceil(s * 0.5));
    }
  }
  return canvas.toDataURL("image/png");
}
