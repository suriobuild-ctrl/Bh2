import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  ArrowUp,
  Box,
  Compass,
  Feather,
  Keyboard,
  MousePointer2,
  Mountain,
  Pause,
  Pickaxe,
  Play,
  RotateCcw,
  Shovel,
} from "lucide-react";
import { HOTBAR } from "@/game/blocks";
import { Engine, type HudSnapshot, type PhaseInfo } from "@/game/engine";

const EMPTY: HudSnapshot = {
  x: 0,
  y: 0,
  z: 0,
  facing: "N",
  slot: 0,
  mine: 0,
  target: "",
  flying: false,
  fps: 0,
  debug: false,
  debugText: "",
};

declare global {
  interface Window {
    __blockhold?: Engine;
  }
}

export function BlockholdApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [engine, setEngine] = useState<Engine | null>(null);
  const [info, setInfo] = useState<PhaseInfo>({ phase: "loading", hasSave: false, seed: 0 });
  const [hud, setHud] = useState<HudSnapshot>(EMPTY);
  const [touch, setTouch] = useState(false);
  const [fail, setFail] = useState("");
  const [seedText, setSeedText] = useState("1024");
  const [confirmFresh, setConfirmFresh] = useState(false);

  useEffect(() => {
    const q = window.matchMedia("(pointer: coarse), (max-width: 840px)");
    const apply = () => setTouch(q.matches);
    apply();
    q.addEventListener("change", apply);
    return () => q.removeEventListener("change", apply);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let alive = true;
    const eng = new Engine(canvas, {
      onPhase: (next) => {
        if (!alive) return;
        setInfo(next);
        setSeedText(String(next.seed));
      },
      onHud: (next) => {
        if (alive) setHud(next);
      },
      onNeedTouch: () => {
        if (alive) setTouch(true);
      },
      onFail: (message) => {
        if (alive) setFail(message);
      },
    });
    engineRef.current = eng;
    window.__blockhold = eng;
    setEngine(eng);
    void eng.start().catch((err: unknown) => {
      if (!alive) return;
      setFail(err instanceof Error ? err.message : "The valley failed to form.");
    });
    return () => {
      alive = false;
      if (window.__blockhold === eng) delete window.__blockhold;
      eng.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    engine?.setTouchMode(touch);
  }, [engine, touch]);

  const phase = info.phase;
  const playing = phase === "play" || phase === "pause";

  return (
    <div className="bh-root">
      <canvas ref={canvasRef} className="bh-gl" aria-label="Blockhold world" />
      {touch && phase === "play" ? <LookPad onLook={(dx, dy) => engineRef.current?.setTouchLook(dx, dy)} /> : null}
      {touch && phase === "play" ? <TouchControls /> : null}
      {playing ? <Hud hud={hud} touch={touch} /> : null}
      {phase === "loading" || fail ? (
        <div className="bh-scrim">
          <div className="bh-loading">
            {fail || "Raising the valley"}
            {fail ? null : (
              <div className="bh-bar" aria-hidden>
                <i />
              </div>
            )}
          </div>
        </div>
      ) : null}
      {phase === "menu" ? (
        <div className="bh-scrim">
          <section className="bh-card" aria-label="Blockhold menu">
            <div className="bh-kicker">Build mode</div>
            <h1 className="bh-title">Blockhold</h1>
            <p className="bh-lead">
              A quiet valley of cubes. Mine the hills, place what you like, and shape a place of your own.
            </p>
            <div className="bh-icons" aria-hidden>
              {[1, 2, 3, 5].map((id) => (
                <img key={id} alt="" width={48} height={48} src={engine?.icons.get(id) ?? ""} />
              ))}
            </div>
            {info.hasSave ? (
              <p className="bh-saved">Saved valley · seed {info.seed}</p>
            ) : (
              <div className="bh-row">
                <label className="bh-label" htmlFor="seed">
                  Seed
                </label>
                <input
                  id="seed"
                  className="bh-input"
                  inputMode="numeric"
                  value={seedText}
                  onChange={(e) => setSeedText(e.target.value.replace(/[^\d-]/g, "").slice(0, 9))}
                />
              </div>
            )}
            {confirmFresh ? (
              <div className="bh-actions">
                <p className="bh-lead">A fresh valley replaces the one saved on this device.</p>
                <button className="bh-btn bh-btn-primary" type="button" onClick={() => engineRef.current?.startFresh(randomSeed())}>
                  <RotateCcw size={16} /> Replace and play
                </button>
                <button className="bh-btn bh-btn-ghost" type="button" onClick={() => setConfirmFresh(false)}>
                  Cancel
                </button>
              </div>
            ) : (
              <div className="bh-actions">
                <button
                  id="play-btn"
                  className="bh-btn bh-btn-primary"
                  type="button"
                  onClick={() => {
                    const eng = engineRef.current;
                    if (!eng) return;
                    if (info.hasSave) eng.play();
                    else {
                      const seed = parseSeed(seedText, info.seed);
                      if (seed !== info.seed) eng.startFresh(seed);
                      else eng.play();
                    }
                  }}
                >
                  <Play size={16} /> Play
                </button>
                {info.hasSave ? (
                  <button className="bh-btn" type="button" onClick={() => setConfirmFresh(true)}>
                    Fresh world
                  </button>
                ) : null}
              </div>
            )}
            <div className="bh-help">
              <div>
                <Keyboard size={16} aria-hidden /> WASD to walk
              </div>
              <div>
                <MousePointer2 size={16} aria-hidden /> Drag or click to look
              </div>
              <div>
                <Pickaxe size={16} aria-hidden /> Hold to mine
              </div>
              <div>
                <Shovel size={16} aria-hidden /> Right click places
              </div>
              <div>
                <Mountain size={16} aria-hidden /> Double-tap jump to fly
              </div>
              <div>
                <Compass size={16} aria-hidden /> Q and E turn
              </div>
            </div>
          </section>
        </div>
      ) : null}
      {phase === "pause" && engine ? (
        <div className="bh-scrim">
          <PauseCard
            engine={engine}
            onResume={() => engineRef.current?.resume()}
            onQuit={() => {
              setConfirmFresh(false);
              engineRef.current?.quit();
            }}
          />
        </div>
      ) : null}
    </div>
  );
}

function Hud({ hud, touch }: { hud: HudSnapshot; touch: boolean }) {
  return (
    <div className="bh-hud">
      <div className="bh-top">
        <div className="bh-coords">
          <b>{hud.facing}</b> {hud.x} {hud.y} {hud.z}
        </div>
        <button className="bh-icon-btn" type="button" aria-label="Pause" onClick={() => currentEngine()?.pause()}>
          <Pause size={18} />
        </button>
      </div>
      {hud.flying ? <div className="bh-fly">Flying</div> : null}
      <Hint touch={touch} />
      <div className="bh-cross" aria-hidden>
        {hud.mine > 0 ? <div className="bh-mine" style={{ ["--p" as string]: String(hud.mine) }} /> : null}
      </div>
      {hud.target ? <div className="bh-target">{hud.target}</div> : null}
      {hud.debug ? <div className="bh-debug">{hud.debugText}</div> : null}
      <div className="bh-hotbar" role="toolbar" aria-label="Blocks">
        {HOTBAR.map((id, i) => (
          <HotSlot key={id} index={i} on={hud.slot === i} src={currentEngine()?.icons.get(id) ?? ""} />
        ))}
      </div>
    </div>
  );
}

function HotSlot({ index, on, src }: { index: number; on: boolean; src: string }) {
  return (
    <button
      type="button"
      className={on ? "bh-slot is-on" : "bh-slot"}
      aria-label={`Block ${index + 1}`}
      onClick={() => currentEngine()?.selectSlot(index)}
    >
      <span>{index + 1}</span>
      {src ? <img alt="" src={src} /> : null}
    </button>
  );
}

function Hint({ touch }: { touch: boolean }) {
  const [on, setOn] = useState(true);
  useEffect(() => {
    const t = window.setTimeout(() => setOn(false), 7000);
    return () => window.clearTimeout(t);
  }, []);
  if (!on) return null;
  return (
    <div className="bh-hint">
      {touch
        ? "Left stick moves. Drag the right side to look. Buttons mine, place, and jump."
        : "WASD move · mouse looks · hold left click to mine · right click places · double-tap Space to fly · Q/E turn"}
    </div>
  );
}

function LookPad({ onLook }: { onLook: (dx: number, dy: number) => void }) {
  const last = useRef<{ id: number; x: number; y: number } | null>(null);
  return (
    <div
      className="bh-look"
      onPointerDown={(e) => {
        if ((e.target as HTMLElement).closest("[data-control]")) return;
        last.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
        e.currentTarget.setPointerCapture(e.pointerId);
      }}
      onPointerMove={(e) => {
        const prev = last.current;
        if (!prev || prev.id !== e.pointerId) return;
        onLook(e.clientX - prev.x, e.clientY - prev.y);
        prev.x = e.clientX;
        prev.y = e.clientY;
      }}
      onPointerUp={(e) => {
        if (last.current?.id === e.pointerId) last.current = null;
      }}
      onPointerCancel={() => {
        last.current = null;
      }}
    />
  );
}

function TouchControls() {
  return (
    <>
      <Stick />
      <div className="bh-pad" data-control="1">
        <Hold name="attack" label="Mine">
          <Pickaxe size={22} />
        </Hold>
        <Hold name="jump" label="Jump" className="bh-jump">
          <ArrowUp size={26} />
        </Hold>
        <Hold name="use" label="Place">
          <Box size={22} />
        </Hold>
        <button
          type="button"
          className="bh-wide"
          aria-label="Toggle fly"
          onPointerDown={(e) => {
            e.preventDefault();
            e.stopPropagation();
            currentEngine()?.toggleFly();
          }}
        >
          <Feather size={18} />
        </button>
      </div>
    </>
  );
}

function Hold({
  name,
  label,
  className,
  children,
}: {
  name: "jump" | "attack" | "use";
  label: string;
  className?: string;
  children: ReactNode;
}) {
  const [down, setDown] = useState(false);
  const set = (v: boolean) => {
    setDown(v);
    currentEngine()?.setTouchButton(name, v);
  };
  const cls = [className, down ? "is-down" : ""].filter(Boolean).join(" ");
  return (
    <button
      type="button"
      className={cls || undefined}
      aria-label={label}
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        set(true);
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        set(false);
      }}
      onPointerCancel={() => set(false)}
    >
      {children}
    </button>
  );
}

function Stick() {
  const origin = useRef({ x: 0, y: 0 });
  const id = useRef<number | null>(null);
  const [nub, setNub] = useState({ x: 0, y: 0 });
  const max = 42;
  const move = (clientX: number, clientY: number) => {
    const dx = clientX - origin.current.x;
    const dy = clientY - origin.current.y;
    const mag = Math.hypot(dx, dy) || 1;
    const k = mag > max ? max / mag : 1;
    const x = dx * k;
    const y = dy * k;
    setNub({ x, y });
    currentEngine()?.setTouchMove(x / max, -y / max);
  };
  return (
    <div
      className="bh-stick"
      data-control="1"
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        id.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        const rect = e.currentTarget.getBoundingClientRect();
        origin.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
        move(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (id.current !== e.pointerId) return;
        move(e.clientX, e.clientY);
      }}
      onPointerUp={(e) => {
        if (id.current !== e.pointerId) return;
        id.current = null;
        setNub({ x: 0, y: 0 });
        currentEngine()?.setTouchMove(0, 0);
      }}
      onPointerCancel={() => {
        id.current = null;
        setNub({ x: 0, y: 0 });
        currentEngine()?.setTouchMove(0, 0);
      }}
    >
      <div className="bh-nub" style={{ transform: `translate(${nub.x}px, ${nub.y}px)` }} />
    </div>
  );
}

function PauseCard({ engine, onResume, onQuit }: { engine: Engine; onResume: () => void; onQuit: () => void }) {
  const [sens, setSens] = useState(engine.getSens());
  const [invert, setInvert] = useState(engine.getInvert());
  return (
    <section className="bh-card" aria-label="Paused">
      <div className="bh-kicker">Paused</div>
      <h2 className="bh-title">Valley waits</h2>
      <p className="bh-lead">Your blocks stay on this device.</p>
      <div className="bh-actions">
        <button className="bh-btn bh-btn-primary" type="button" onClick={onResume}>
          <Play size={16} /> Resume
        </button>
        <button className="bh-btn" type="button" onClick={onQuit}>
          Save and leave
        </button>
      </div>
      <div className="bh-row bh-split">
        <label className="bh-label" htmlFor="sens">
          Look
        </label>
        <input
          id="sens"
          type="range"
          min={0.0008}
          max={0.006}
          step={0.0001}
          value={sens}
          onChange={(e) => {
            const v = Number(e.target.value);
            setSens(v);
            engine.setSens(v);
          }}
        />
      </div>
      <label className="bh-row">
        <input
          type="checkbox"
          checked={invert}
          onChange={(e) => {
            setInvert(e.target.checked);
            engine.setInvert(e.target.checked);
          }}
        />
        <span className="bh-label">Invert look</span>
      </label>
    </section>
  );
}

function currentEngine(): Engine | null {
  return window.__blockhold ?? null;
}

function parseSeed(text: string, fallback: number) {
  const n = Number(text);
  if (!Number.isFinite(n)) return fallback || 1024;
  return Math.floor(n);
}

function randomSeed() {
  return Math.floor(Math.random() * 900000) + 1000;
}
